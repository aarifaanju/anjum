Use OYODB
Go

Create Table OYOCustomer (
	CustomerID Int Primary Key Identity(2000,1),
	CustomerName Varchar(50) Not Null,
	Address Varchar(50) Not Null,
	IDDoc Varchar(50)
)
Go

Create Table OYOBooking (
	BookingID Int Primary Key Identity(5000,1),
	HotelID Int,
	CustomerID Int Foreign Key References OYOCustomer(CustomerID),
	DateIn DateTime,
	DateOut DateTime,
	RoomType int
)
Go

Create Procedure AddBooking (
	@customerName varchar(50),
	@address varchar(50),
	@idDoc int,
	@hotelID int,
	@city varchar(50),
	@checkinDate DateTime,
	@checkoutDate DateTime,
	@roomType int
)
As
Begin
	Insert into OYOCustomer Values (@customerName, @address, @idDoc);
	Declare @customerID Int;
	Set @customerID = (Select max(CustomerID) from OYOCustomer);
	Insert into OYOBooking Values (@hotelID, @customerID, @checkinDate, @checkoutDate, @roomType);
End
Go
