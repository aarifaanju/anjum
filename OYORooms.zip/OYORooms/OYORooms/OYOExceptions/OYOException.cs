﻿using System;

namespace OYOExceptions {
    public class OYOException {
        public static string exception = "";
    }
}
