﻿using System;
using OYOEntities;
using OYOExceptions;
using OYOBAL;

namespace OYORooms {
    public partial class BookRoom : System.Web.UI.Page {
        protected void Page_Load(object sender, EventArgs e) {

        }

        protected void bookTicketButton_Click(object sender, EventArgs e) {
            BookingEntity booking = new BookingEntity();
            booking.CUSTOMER_NAME = customerNameTextBox.Text;
            booking.ADDRESS = addressTextBox.Text;
            booking.ID_PROOF = Convert.ToInt32(idDropDown.SelectedValue);
            booking.HOTEL_ID = Convert.ToInt32(hotelDropDown.SelectedValue);
            booking.CITY = cityDropDown.SelectedValue;
            booking.CHECKIN_DATE = Convert.ToDateTime(checkinDatePicker.Text);
            booking.CHECKOUT_DATE = Convert.ToDateTime(checkoutDatePicker.Text);
            booking.ROOM_TYPE = Convert.ToInt32(roomTypeDropDown.SelectedValue);
            bookingStatusLabel.Text = booking.CHECKIN_DATE.ToString();
            if(CBAL.MAddBookingBAL(booking)) {
                int noOfDays = Convert.ToInt32((booking.CHECKOUT_DATE - booking.CHECKIN_DATE).TotalDays);
                int roomType = booking.ROOM_TYPE;
                int total = roomType * noOfDays;
                string str = "Total Amount to be Paid: " + total;
                bookingStatusLabel.Text = str;
            } else {
                bookingStatusLabel.Text = OYOException.exception;
            }
        }
    }
}