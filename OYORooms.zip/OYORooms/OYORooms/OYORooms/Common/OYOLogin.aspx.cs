﻿using System;
using OYOEntities;
using System.Web.Security;

namespace OYORooms {
    public partial class OYOLogin : System.Web.UI.Page {
        protected void Page_Load(object sender, EventArgs e) {

        }

        protected void loginButton_Click(object sender, EventArgs e) {
            if(usernameTextBox.Text.Equals(LoginEntity.USERNAME)) {
                if(passwordTextBox.Text.Equals(LoginEntity.PASSWORD)) {
                    FormsAuthentication.RedirectFromLoginPage(@"BookRoom.aspx",false);
                } else {
                    statusLabel.Text = "Password Incorrect";
                }
            } else {
                statusLab   = "Username Incorrect";
            }
        }
    }
}