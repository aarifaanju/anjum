﻿using System;

namespace OYOEntities {
    public class BookingEntity {
        public string CUSTOMER_NAME { get; set; }
        public string ADDRESS { get; set; }
        public int ID_PROOF { get; set; }
        public int HOTEL_ID { get; set; }
        public string CITY { get; set; }
        public DateTime CHECKIN_DATE { get; set; }
        public DateTime CHECKOUT_DATE { get; set; }
        public int ROOM_TYPE { get; set; }
    }
}
