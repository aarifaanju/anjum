﻿using System;

namespace OYOEntities {
    public class LoginEntity {
        private const string _username = "admin";
        private const string _password = "admin";
        public static string USERNAME { get { return _username; } }
        public static string PASSWORD { get { return _password; } }
    }
}
