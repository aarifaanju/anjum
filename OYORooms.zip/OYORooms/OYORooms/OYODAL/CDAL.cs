﻿using System;
using OYOEntities;
using OYOExceptions;
using System.Data.Common;
using System.Data;

namespace OYODAL {
    public class CDAL {
        public static bool MAddBookingDAL(BookingEntity booking) {
            bool bookingDone = false;
            DbCommand cmd = null;
            DbParameter param = null;
            try {
                cmd = DataConnection.CreateCommand();
                cmd.CommandText = "AddBooking";

                param = cmd.CreateParameter();
                param.ParameterName = "@customerName";
                param.DbType = DbType.String;
                param.Value = booking.CUSTOMER_NAME;
                cmd.Parameters.Add(param);
                param = null;

                param = cmd.CreateParameter();
                param.ParameterName = "@address";
                param.DbType = DbType.String;
                param.Value = booking.ADDRESS;
                cmd.Parameters.Add(param);
                param = null;

                param = cmd.CreateParameter();
                param.ParameterName = "@idDoc";
                param.DbType = DbType.Int32;
                param.Value = booking.ID_PROOF;
                cmd.Parameters.Add(param);
                param = null;

                param = cmd.CreateParameter();
                param.ParameterName = "@hotelID";
                param.DbType = DbType.Int32;
                param.Value = booking.HOTEL_ID;
                cmd.Parameters.Add(param);
                param = null;

                param = cmd.CreateParameter();
                param.ParameterName = "@city";
                param.DbType = DbType.String;
                param.Value = booking.CITY;
                cmd.Parameters.Add(param);
                param = null;

                param = cmd.CreateParameter();
                param.ParameterName = "@checkinDate";
                param.DbType = DbType.DateTime;
                param.Value = booking.CHECKIN_DATE;
                cmd.Parameters.Add(param);
                param = null;

                param = cmd.CreateParameter();
                param.ParameterName = "@checkoutDate";
                param.DbType = DbType.DateTime;
                param.Value = booking.CHECKOUT_DATE;
                cmd.Parameters.Add(param);
                param = null;

                param = cmd.CreateParameter();
                param.ParameterName = "@roomType";
                param.DbType = DbType.Int32;
                param.Value = booking.ROOM_TYPE;
                cmd.Parameters.Add(param);
                param = null;

                int affectedRows = DataConnection.ExecuteNonQueryCommand(cmd);
                if(affectedRows > 0) {
                    bookingDone = true;
                }
            } catch (Exception ex) {
                OYOException.exception += ex.ToString();
            }

            return bookingDone;
        }
    }
}
