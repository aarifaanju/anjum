﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;

namespace OYODAL
{
    public class ConfigurationDAL
    {
        private static string providerName;

        public static string ProviderName
        {
            get { return ConfigurationDAL.providerName; }
            set { ConfigurationDAL.providerName = value; }
        }
        private static string connectionString;

        public static string ConnectionString
        {
            get { return ConfigurationDAL.connectionString; }
            set { ConfigurationDAL.connectionString = value; }
        }

        static ConfigurationDAL()
        {
            providerName = ConfigurationManager.ConnectionStrings["OYOConnection"].ProviderName;
            connectionString = ConfigurationManager.ConnectionStrings["OYOConnection"].ConnectionString;

        }
    }

}
