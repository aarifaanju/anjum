﻿using System;
using OYOEntities;
using OYODAL;

namespace OYOBAL {
    public class CBAL {
        public static bool MAddBookingBAL(BookingEntity booking) {
            if (MValidateDate(booking)) {
                return CDAL.MAddBookingDAL(booking);
            } else {
                return false;
            }
        }
        private static bool MValidateDate(BookingEntity booking) {
            if ((booking.CHECKOUT_DATE - booking.CHECKIN_DATE).TotalDays < 0) {
                return false;
            } else {
                return true;
            }
        }
    }
}
